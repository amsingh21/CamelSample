package org.employee.employee;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.employee.employee.EmployeeRequest;
import org.employee.employee.EmployeeResponse;

public class EmployeeImpl implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		System.out.println("response prepared 1");
		exchange.getOut().setBody(getEmployeeDetails(exchange.getIn().getBody(EmployeeRequest.class)));
		System.out.println("response prepared 2");
	}

	public EmployeeResponse getEmployeeDetails(EmployeeRequest request) {

		System.out.println("getEmployeeDetails in getEmployeeDetails");
		EmployeeResponse response = new EmployeeResponse();
		response.setEmployeeName("Amita");
		response.setEmployeeAge("16");
		response.setEmployeeDOJ("15-01-2019");

		return response;
	}

}
