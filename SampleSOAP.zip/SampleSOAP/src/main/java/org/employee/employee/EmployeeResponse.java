
package org.employee.employee;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="EmployeeName" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="EmployeeAddress" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="EmployeeAge" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="EmployeeDOJ" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "employeeName",
    "employeeAddress",
    "employeeAge",
    "employeeDOJ"
})
@XmlRootElement(name = "EmployeeResponse")
public class EmployeeResponse {

    @XmlElement(name = "EmployeeName", required = true)
    protected String employeeName;
    @XmlElement(name = "EmployeeAddress", required = true)
    protected String employeeAddress;
    @XmlElement(name = "EmployeeAge", required = true)
    protected String employeeAge;
    @XmlElement(name = "EmployeeDOJ", required = true)
    protected String employeeDOJ;

    /**
     * Gets the value of the employeeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeName() {
        return employeeName;
    }

    /**
     * Sets the value of the employeeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeName(String value) {
        this.employeeName = value;
    }

    /**
     * Gets the value of the employeeAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeAddress() {
        return employeeAddress;
    }

    /**
     * Sets the value of the employeeAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeAddress(String value) {
        this.employeeAddress = value;
    }

    /**
     * Gets the value of the employeeAge property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeAge() {
        return employeeAge;
    }

    /**
     * Sets the value of the employeeAge property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeAge(String value) {
        this.employeeAge = value;
    }

    /**
     * Gets the value of the employeeDOJ property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeDOJ() {
        return employeeDOJ;
    }

    /**
     * Sets the value of the employeeDOJ property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeDOJ(String value) {
        this.employeeDOJ = value;
    }

}
